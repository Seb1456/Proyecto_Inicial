
/**
 * Write a description of class Lid here.
 * 
 * @author Paula Díaz 
 * @author Sebastian Granados 
 * 
 * @version 1
 */
public class Lid{

    private int number;
    private String color;
    private Rectangle top;
    private int xPos;
    private int yPos;

    public Lid(int number, String color){
        this.number = number;
        this.color = color;
        xPos = 0;
        yPos = 0;
        top = new Rectangle();
        top.changeSize(5, 40); 
        top.changeColor(color);
    }

    public int getNumber() {
        return number;
    }

    public void draw(int x, int y) {
        xPos = x;
        yPos = y;

        top.moveHorizontal(xPos);
        top.moveVertical(yPos);
    }

    public void moveVertical(int distance) {
        yPos += distance;
        top.moveVertical(distance);
    }

    public void moveHorizontal(int distance) {
        xPos += distance;
        top.moveHorizontal(distance);
    }

    public void makeVisible() {
        top.makeVisible();
    }

    public void makeInvisible() {
        top.makeInvisible();
    }
}