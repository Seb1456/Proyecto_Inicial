
/**
 * Write a description of class Tower here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;

public class Tower {

    private int width;
    private int maxHeight;
    private boolean visible;

    private Stack<Cup> cups;
    private boolean ok;

    private int baseX = 120;
    private int baseY = 260;

    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;
        this.visible = true;
        this.cups = new Stack<>();
        this.ok = true;
    }

    public void pushCup(int n) {

        ok = false;

        if (cups.size() >= maxHeight) return;
        if (exists(n)) return;

        Cup c = new Cup(n);
        cups.push(c);

        reorganize();

        if (visible) c.makeVisible();

        ok = true;
    }

    public void popCup() {

        ok = false;

        if (cups.isEmpty()) return;

        Cup c = cups.pop();
        c.makeInvisible();

        reorganize();
        ok = true;
    }

    public void removeCup(int n) {

        ok = false;

        Stack<Cup> temp = new Stack<>();
        boolean found = false;

        while (!cups.isEmpty()) {
            Cup c = cups.pop();
            if (c.getNumber() == n) {
                c.makeInvisible();
                found = true;
                break;
            }
            temp.push(c);
        }

        while (!temp.isEmpty()) {
            cups.push(temp.pop());
        }

        reorganize();
        ok = found;
    }

    public void orderTower() {

        ok = false;

        List<Cup> list = new ArrayList<>(cups);
        Collections.sort(list, Comparator.comparingInt(Cup::getNumber));

        cups.clear();
        cups.addAll(list);

        reorganize();
        ok = true;
    }

    public void reverseTower() {

        ok = false;

        Collections.reverse(cups);
        reorganize();
        ok = true;
    }

    private void reorganize() {

        int currentY = baseY;

        for (Cup c : cups) {
            c.draw(baseX, currentY - c.getHeight());
            currentY -= c.getHeight();
        }
    }

    private boolean exists(int n) {
        for (Cup c : cups) {
            if (c.getNumber() == n) return true;
        }
        return false;
    }

    public void makeVisible() {
        visible = true;
        for (Cup c : cups) c.makeVisible();
    }

    public void makeInvisible() {
        visible = false;
        for (Cup c : cups) c.makeInvisible();
    }

    public boolean ok() {
        return ok;
    }
}