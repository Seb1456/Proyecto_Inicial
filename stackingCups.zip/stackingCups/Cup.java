
/**
 * Write a description of class Cup here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cup {

    private int number;
    private int xPos;
    private int yPos;
    private String color;

    private Rectangle leftWall;
    private Rectangle rightWall;
    private Rectangle base;

    private Lid lid;

    private static final int HEIGHT = 40;
    private static final int WIDTH = 40;

    public Cup(int number) {
        this.number = number;
        this.color = assignColor(number);
        xPos = 0;
        yPos = 0;
        leftWall = new Rectangle();
        rightWall = new Rectangle();
        base = new Rectangle();

        configureShapes();
    }

    private void configureShapes() {

        leftWall.changeSize(HEIGHT, 5);
        leftWall.changeColor(color);

        rightWall.changeSize(HEIGHT, 5);
        rightWall.changeColor(color);

        base.changeSize(5, WIDTH);
        base.changeColor(color);
    }

    private String assignColor(int n) {
        switch (n % 6) {
            case 0: return "red";
            case 1: return "blue";
            case 2: return "green";
            case 3: return "yellow";
            case 4: return "magenta";
            default: return "cyan";
        }
    }
    
    public void draw(int x, int y) {
    
        int dx = x - xPos;
        int dy = y - yPos;
    
        xPos = x;
        yPos = y;
    
        // Pared izquierda
        leftWall.moveHorizontal(dx);
        leftWall.moveVertical(dy);
    
        // Pared derecha(posición correcta)
        rightWall.moveHorizontal(dx);
        rightWall.moveVertical(dy);
    
        // Base
        base.moveHorizontal(dx);
        base.moveVertical(dy);
    
        // Ajuste 
        rightWall.moveHorizontal(WIDTH - 5);
        base.moveVertical(HEIGHT - 5);

    }

    public void moveVertical(int distance) {
        yPos += distance;

        leftWall.moveVertical(distance);
        rightWall.moveVertical(distance);
        base.moveVertical(distance);
     }

    public void makeVisible() {
        leftWall.makeVisible();
        rightWall.makeVisible();
        base.makeVisible();
    }

    public void makeInvisible() {
        leftWall.makeInvisible();
        rightWall.makeInvisible();
        base.makeInvisible();
    }

    public int getNumber() {
        return number;
    }

    public int getHeight() {
        return HEIGHT;
    }

    public Lid getLid() {
        return lid;
    }
}