import java.util.*;
/**
 * Class Tower
 * 
 * @author Paula Díaz 
 * @author Sebastian Granados 
 * 
 * @version 2
 */

public class Tower {

    private int width;
    private int maxHeight;
    private boolean visible;
    private Rectangle leftSide;
    private Rectangle baseLine;
    private ArrayList<Rectangle> heightMarks;

    private Stack<Cup> cups;
    private Stack<Lid> lids;
    private boolean ok;

    private int baseX = 120;
    private int baseY = 260;
    
    /**
     * Build a tower with the width and max height
     * @param int width
     * @param int maxHeight
     */
    public Tower(int width, int maxHeight) {

        this.width = width;
        this.maxHeight = maxHeight;
        this.visible = true;
        this.cups = new Stack<>();
        this.lids = new Stack<>();
        this.ok = true;
        baseX = -35;
        baseY = 450;
    
        leftSide = new Rectangle();
        baseLine = new Rectangle();
        heightMarks = new ArrayList<>();
    
        int towerHeightPixels = maxHeight * 40;
        int towerWidthPixels = width * 40;
    
        // Pared
        leftSide.changeSize(towerHeightPixels, 5);
        leftSide.moveHorizontal(baseX);
        leftSide.moveVertical(baseY - towerHeightPixels);
        leftSide.changeColor("black");

        // Base
        baseLine.changeSize(5, towerWidthPixels);
        baseLine.moveHorizontal(baseX);
        baseLine.moveVertical(baseY);
        baseLine.changeColor("black");
    
        // Marca para cada cm
        for (int i = 1; i <= maxHeight; i++) {
    
            Rectangle mark = new Rectangle();
            mark.changeSize(2, 15);
            mark.changeColor("black");
    
            int markY = baseY - (i * 40);
    
            mark.moveHorizontal(baseX - 15);
            mark.moveVertical(markY);
    
            heightMarks.add(mark);
        }

        if (visible) {
            leftSide.makeVisible();
            baseLine.makeVisible();
    
            for (Rectangle r : heightMarks) {
                r.makeVisible();
            }
        }
    }
    
    /**
     * Build a tower with the number of cups
     * @param int cups
     */
    public Tower(int cups) {
        
        
    }
    
    /**
     * Put a cup with the size of the cup
     * @param int n
     */
    public void pushCup(int n) {
    
        if (n <= 0 || n > width) {
            ok = false;
            return;
        }
    
        if (cups.size() >= maxHeight) {
            ok = false;
            return;
        }
        
        Cup c = new Cup(n); 
        cups.push(c); 
        reorganize(); 
        if (visible) c.makeVisible(); 
        ok = true;
    }
    
    /**
     * Pop a selected cup 
     */
    public void popCup() {
        ok = false;

        if (cups.isEmpty()) return;
        Cup c = cups.pop();
        c.makeInvisible();
        reorganize();
        
        ok = true;
    }

    /**
     * Remove a cup with the selected number
     * @param int n
     */
    public void removeCup(int n) {

        ok = false;
        Stack<Cup> temp = new Stack<>();
        boolean found = false;

        while (!cups.isEmpty()) {
            Cup c = cups.pop();
            if (c.getNumber() == n) {
                c.makeInvisible();
                found = true;
                break;
            }
            temp.push(c);
        }

        while (!temp.isEmpty()) {
            cups.push(temp.pop());
        }

        reorganize();
        ok = found;
    }
    
    /**
     * Put a lid with the selected number
     * @param int n
     */
    public void pushLid(int n) {
        ok = false;

        Lid l = new Lid(n);
        lids.push(l);
        reorganize();
        if (visible) l.makeVisible();
        ok = true;
    }
    
    /**
     * Pop a selected lid 
     */
    public void popLid() {
        ok = false;

        if (lids.isEmpty()) return;
        Lid l = lids.pop();
        l.makeInvisible();
        reorganize();
        
        ok = true;
    }
    
    /**
     * Remove a lid with the selected number
     * @param int n
     */
    public void removeLid(int n) {

        ok = false;
        Stack<Lid> temp = new Stack<>();
        boolean found = false;

        while (!lids.isEmpty()) {
            Lid l = lids.pop();
            if (l.getNumber() == n) {
                l.makeInvisible();
                found = true;
                break;
            }
            temp.push(l);
        }

        while (!temp.isEmpty()) {
            lids.push(temp.pop());
        }

        reorganize();
        ok = found;
    }

    
    public void orderTower() {

        ok = false;

        List<Cup> list = new ArrayList<>(cups);
        Collections.sort(list, Comparator.comparingInt(Cup::getNumber));
        cups.clear();
        cups.addAll(list);
        reorganize();
        
        ok = true;
    }

    public void reverseTower() {

        ok = false;

        Collections.reverse(cups);
        reorganize();
        
        ok = true;
    }

    private void reorganize() {
        int currentY = baseY;
        int torreWidthPixels = width * 40;                  
        int centroTorreX = baseX + (torreWidthPixels / 2);
    
        for (Cup c : cups) {
            int mitadAnchoTaza = c.getWidth() / 2;
            int xCentrada      = centroTorreX - mitadAnchoTaza;
            c.draw(xCentrada, currentY - c.getHeight());
            
            if (c.getLid() != null) {
                Lid l = c.getLid();
                int mitadAncholid = l.getWidth() / 2;
                int lidX = centroTorreX - mitadAncholid;
                int lidY = currentY - c.getHeight();
                l.draw(lidX, lidY);
            }
    
            currentY -= c.getHeight();
        }
        
        for (Lid l : lids) {
            int mitadAncho = l.getWidth() / 2;
            int lidX = centroTorreX - mitadAncho;
        
            boolean found = false;
            currentY = baseY;
        
            for (Cup c : cups) {
                if (c.getNumber() == l.getNumber()) {
                    int lidY = currentY - c.getHeight();
                    l.draw(lidX, lidY);
                    found = true;
                    break;
                }
                currentY -= c.getHeight();
            }
        
            if (!found) {
                int lidY = baseY - (maxHeight * 40) - 50;
                l.draw(lidX, lidY);
            }
        }
    }
    
    public void swap(String[] o1,String[] o2){
        
    }
    
    public void cover() {

        for (Cup c : cups) {
            if (!c.hasLid()) {
                c.addLid();
            }
        }
    
        updatePositions();
        ok = true;
    }
    
    public int height() {
        return ;
    }
    
    public int[] lidedCups() {
        return ;
    }
        
        public String[] stackingItems() {

        int total = 0;
    
        for (Cup c : cups) {
            total++;
            if (c.hasLid()) {
                total++;
            }
        }
    
        String[] result = new String[total];
        int index = 0;
    
        for (Cup c : cups) {
            result[index++] = "cup-" + c.getNumber();
            if (c.hasLid()) {
                result[index++] = "lid-" + c.getNumber();
            }
        }
    
        return result;
    }
    
    public String[] swapToReduce() {

        for (int i = 0; i < cups.size() - 1; i++) {
    
            if (cups.get(i).getNumber() > cups.get(i + 1).getNumber()) {
    
                String o1 = "cup-" + cups.get(i).getNumber();
                String o2 = "cup-" + cups.get(i + 1).getNumber();
    
                return new String[]{o1, o2};
            }
        }
    
        return new String[0];
    }
    
    private void updatePositions() {

        for (int i = 0; i < cups.size(); i++) {
            cups.get(i).draw(baseX, baseY - (i * 40));
        }
    }
    
    public void makeVisible() {
        visible = true;
        for (Cup c : cups) c.makeVisible();
    }

    public void makeInvisible() {
        visible = false;
        for (Cup c : cups) c.makeInvisible();
    }

    public boolean ok() {
        return ok;
    }
}